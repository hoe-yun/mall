package vo;

public class Customer {

}
