package vo;

public class ManagerPwHistory {
	private int managerPwHistoryNo;
	private int managerNo;
	private String managerPw;
	private String createdate;
	
	public int getManagerPwHistoryNo() {
		return managerPwHistoryNo;
	}
	public void setManagerPwHistoryNo(int managerPwHistoryNo) {
		this.managerPwHistoryNo = managerPwHistoryNo;
	}
	public int getManagerNo() {
		return managerNo;
	}
	public void setManagerNo(int managerNo) {
		this.managerNo = managerNo;
	}
	public String getManagerPw() {
		return managerPw;
	}
	public void setManagerPw(String managerPw) {
		this.managerPw = managerPw;
	}
	public String getCreatedate() {
		return createdate;
	}
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}
}
